import java.io.File;
import java.util.*;

public class MagicalCreaturesGame1 {
	public static File file = new File("creatures.txt");
	static Scanner scan;
	public static ArrayList<MagicalCreature> creatures = new ArrayList<>();
	public static int MOVES;
	public static int alive;
}
